import json
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import boto3
from datetime import datetime
import os


region = 'us-east-1'
lex_client = boto3.client('lex-runtime')
s3_client = boto3.client('s3')
es_client = boto3.client('es')


def lambda_handler(event, context):
    input_text = event["q"]
    input_split = input_text.split("and")
    
    object_1 = input_split[0]
    if len(input_split) > 1:
        object_2 = input_split[-1]
    else:
        object_2 = None

    host = es_client.describe_elasticsearch_domain(DomainName='smart-photo-album-es-<id>')['DomainStatus']['Endpoint']
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, 'es', session_token=credentials.token)
    es = Elasticsearch(
        hosts = [{'host': host, 'port': 443}],
        http_auth = awsauth,
        use_ssl = True,
        verify_certs = True,
        connection_class = RequestsHttpConnection
    )

    query ={
        "query":{
            "bool" : {
                "must" : [
                    {
                        "match" : { "labels" : object_1 }
                    }
                ]
            }
        }
    }
    if object_2:
        must_2 = {
            "match" : { "labels" : object_2 }
        }
        query['query']['bool']['must'].append(must_2)
    print(query)
    es_response = es.search(index="photos", body=query)
    hits = es_response['hits']['hits']
    print(es_response) 
    
    results = []
    if hits:
        for hit in hits:
            source = hit["_source"]
            bucket = source["bucket"]
            objectKey = source["objectKey"]
            url = s3_client.generate_presigned_url('get_object',Params={'Bucket': bucket,'Key': objectKey})
            labels = source['labels']
            results.append({"url":url,"labels":labels})

    return {
        'results':results
    }
